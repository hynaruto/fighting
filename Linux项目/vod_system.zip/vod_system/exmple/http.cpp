#include "httplib.h"
using namespace httplib;
void helloworld(const Request &req,Response &rsp)
{
    rsp.body = "<html><body><h1>Hello world</h1></body></html>";
    rsp.status = 200;
    rsp.set_header("Content-Type","text/html");
}
void upload(const Request &req,Response &rsp)
{
    auto size = req.files.size();
    std::cout<<size<<std::endl;
    auto ret = req.has_file("uploadfile");
    if (ret == false)
    {
        std::cout<<"have no file!\n";
        return;
    }
    const auto& file = req.get_file_value("uploadfile");
    std::cout<<file.name<<std::endl;
    std::cout<<file.filename<<std::endl;
    std::cout<<file.content<<std::endl;
    std::cout<<file.content_type<<std::endl;
    std::fstream of;
}
int main()
{
    httplib::Server srv;
    srv.set_base_dir("./wwwroot");
    srv.Get("/hello",helloworld);
    srv.Get("/hi",helloworld);
    srv.Post("/video",upload);
    srv.listen("0.0.0.0",9000);
    return 0;
}
